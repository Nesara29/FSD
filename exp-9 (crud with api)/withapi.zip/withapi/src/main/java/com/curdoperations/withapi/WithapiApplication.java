package com.curdoperations.withapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WithapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(WithapiApplication.class, args);
	}

}
